pds4_tools.reader.read_arrays module
====================================

.. currentmodule:: pds4_tools.reader.read_arrays

Functions
---------

.. autosummary::

    read_array
    read_array_data
    new_array


Details
-------

.. autofunction:: read_array
.. autofunction:: read_array_data
.. autofunction:: new_array
